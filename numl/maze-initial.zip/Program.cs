﻿using System;
using numl.AI;

namespace Games
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Maze Solver!");
        }
    }
}
