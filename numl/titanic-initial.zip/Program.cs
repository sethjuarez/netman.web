﻿using System;

namespace Games
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Titanic Challenge!");
        }
    }
}
